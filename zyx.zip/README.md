# zyx — Bangladesh News, Minimized

Automated, 100% free **Bangladesh-only** news aggregator on GitHub Pages.
No servers, no paid APIs, no databases, no build step.

## What's inside
- 🇧🇩 Bangladesh-only: BD outlets pass everything; international feeds are keyword-filtered to Bangladesh stories
- ⚡ Instant load via local cache + Service Worker (works offline)
- 🖼️ Article images with graceful fallback
- 🌗 Dark / Light · glassmorphism · Bangla-native typography
- 🔍 Live search in English & বাংলা · source filter · sort · pagination
- 🔖 Bookmarks (localStorage) · share/copy-link · tab counts · live timestamps
- 🤖 GitHub Actions fetches every hour, 8 feeds in parallel, retries, validates before committing

## File structure
```
zyx/
├── index.html
├── styles.css
├── app.js
├── sw.js
├── README.md
├── data/news.json            ← starter file; Actions overwrites hourly
├── scripts/fetch.py
└── .github/workflows/fetch_news.yml
```

## Setup (5 minutes)

1. **Create repo** → [github.com/new](https://github.com/new) → name `zyx` → **Public** → no README.
2. **Upload all files** keeping the structure (on the web: type full paths like `scripts/fetch.py` to auto-create folders).
3. **Enable Pages** → Settings → Pages → Deploy from branch → `main` / root → Save.
4. **First fetch** → Actions → **Fetch News** → Run workflow → wait ~30s.
5. Open `https://<username>.github.io/zyx/` — news is live. Auto-updates forever.

## Troubleshooting

| Problem | Fix |
|---|---|
| Homepage empty | Actions → Fetch News → Run workflow (first run must be triggered manually), wait 30s, hard-refresh (Ctrl+Shift+R) |
| One source missing | Some sites block datacenter IPs; the run log shows `⚠ failed` — that source is skipped, everything else still publishes. Swap the URL in `FEEDS` |
| All sources failing | Check Actions run log; your repo's network may be rate-limited — rerun in an hour |
| Old news showing | The site auto-refreshes every 5 min; verify the workflow's last run in the Actions tab |

## Adding sources
Edit `FEEDS` in `scripts/fetch.py`:
```python
("https://example.com/rss", "top", "Example News", True),     # BD-native: keep all
("https://world.com/rss",   "world", "World News", False),    # int'l: BD-filtered
```
Categories: `top`, `world`, `tech`, `business`, `culture`.

## Local test
```bash
pip install feedparser
python scripts/fetch.py && python -m http.server 8000
```

MIT · No trackers, no ads.
Built by **Ali Hasan** — [instagram.com/ig.alihasan](https://instagram.com/ig.alihasan)
