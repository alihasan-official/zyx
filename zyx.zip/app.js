/* ============================================================
   zyx — app.js v3
   Vanilla JS. Zero dependencies.
   Features: instant offline cache, live search (EN+BN), source
   filter, sort, pagination, bookmarks, share, live timestamps,
   auto-refresh (5 min + on tab focus), service worker, toasts.
   ============================================================ */

"use strict";

/* ---------- Config ---------- */
const DATA_URL = "data/news.json";
const REFRESH_INTERVAL = 5 * 60 * 1000;
const PAGE_SIZE = 24;
const CACHE_KEY = "zyx_cache_v1";
const BOOKMARKS_KEY = "zyx_bookmarks";

const CATEGORIES = {
  top:       { label: "Top Stories",    sub: "The most important stories in Bangladesh right now." },
  world:     { label: "World",          sub: "How the world sees Bangladesh — and what it means." },
  tech:      { label: "Tech & Science", sub: "Innovation, research, and the digital future." },
  business:  { label: "Business",       sub: "Economy, markets, trade, and industry." },
  culture:   { label: "Culture",        sub: "Cricket, cinema, festivals, food, and ideas." },
  bookmarks: { label: "Saved",          sub: "Articles you bookmarked. Stored locally, private to you." }
};

/* ---------- State ---------- */
const state = {
  articles: [],
  bookmarks: loadBookmarks(),
  category: "top",
  query: "",
  source: "all",
  sort: "new",
  shown: PAGE_SIZE,
  lastUpdated: null,
  offline: false
};

/* ---------- DOM ---------- */
const $ = (s) => document.querySelector(s);
const grid = $("#feedGrid");
const tabs = $("#tabs");
const searchInput = $("#searchInput");
const updatedText = $("#updatedText");
const updatedBadge = $("#updatedBadge");
const resultMeta = $("#resultMeta");
const feedTitle = $("#feedTitle");
const feedSub = $("#feedSub");
const emptyState = $("#emptyState");
const emptyTitle = $("#emptyTitle");
const emptyMsg = $("#emptyMsg");
const breakingBar = $("#breakingBar");
const breakingLink = $("#breakingLink");
const sourceFilter = $("#sourceFilter");
const sortSelect = $("#sortSelect");
const loadMoreWrap = $("#loadMoreWrap");
const loadMoreBtn = $("#loadMoreBtn");
const errorBanner = $("#errorBanner");
const errorText = $("#errorText");
const retryBtn = $("#retryBtn");
const toastEl = $("#toast");

const BANGLA_RE = /[\u0980-\u09FF]/;
const hasBangla = (t = "") => BANGLA_RE.test(t);

/* ============================================================
   Storage helpers
   ============================================================ */
function loadBookmarks() {
  try { return new Map(JSON.parse(localStorage.getItem(BOOKMARKS_KEY)) || []); }
  catch { return new Map(); }
}
function saveBookmarks() {
  try { localStorage.setItem(BOOKMARKS_KEY, JSON.stringify([...state.bookmarks])); } catch {}
}
function loadCache() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const { at, data } = JSON.parse(raw);
    if (!data || !Array.isArray(data.articles)) return null;
    if (Date.now() - at > 24 * 60 * 60 * 1000) return null; // stale after 24h
    return data;
  } catch { return null; }
}
function saveCache() {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify({
      at: Date.now(),
      data: { generated_at: state.lastUpdated, articles: state.articles }
    }));
  } catch {}
}

/* ============================================================
   Text helpers
   ============================================================ */
function escapeHTML(str = "") {
  return str.replace(/[&<>"']/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));
}

function timeAgo(iso) {
  if (!iso) return "";
  const diff = Date.now() - new Date(iso).getTime();
  if (Number.isNaN(diff) || diff < 0) return "";
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return d === 1 ? "yesterday" : `${d}d ago`;
}

function formatUpdated(iso) {
  if (!iso) return "awaiting first sync";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString(undefined, {
    month: "short", day: "numeric", hour: "2-digit", minute: "2-digit"
  });
}

let toastTimer;
function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2200);
}

/* ============================================================
   Data
   ============================================================ */
async function fetchNews({ silent = false } = {}) {
  if (!silent && state.articles.length === 0) renderSkeletons();
  try {
    const res = await fetch(`${DATA_URL}?t=${Date.now()}`, {
      headers: { "Accept": "application/json" },
      cache: "no-store"
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    if (!Array.isArray(data.articles)) throw new Error("Malformed data");

    state.articles = data.articles;
    state.lastUpdated = data.generated_at || null;
    state.offline = false;
    saveCache();
    errorBanner.hidden = true;
    render();
  } catch (err) {
    console.error("zyx: load failed:", err);
    state.offline = true;
    if (state.articles.length === 0) {
      renderError();
    } else {
      render(); // keep showing cached data, badge shows offline
      toast("Offline — showing last saved news");
    }
  }
}

/* ============================================================
   Filtering
   ============================================================ */
function visibleArticles() {
  let list;
  if (state.category === "bookmarks") {
    list = [...state.bookmarks.values()];
  } else if (state.category === "top") {
    list = state.articles.filter(a => a.category === "top");
    if (list.length === 0) list = state.articles.slice();
  } else {
    list = state.articles.filter(a => a.category === state.category);
  }

  if (state.source !== "all") {
    list = list.filter(a => a.source === state.source);
  }

  const q = state.query.trim().toLowerCase();
  if (q) {
    list = list.filter(a =>
      (a.title || "").toLowerCase().includes(q) ||
      (a.summary || "").toLowerCase().includes(q) ||
      (a.source || "").toLowerCase().includes(q)
    );
  }

  list.sort((a, b) => {
    const ta = a.published || "", tb = b.published || "";
    return state.sort === "new" ? (tb > ta ? 1 : -1) : (ta > tb ? 1 : -1);
  });

  return list;
}

function categoryCounts() {
  const counts = { top: 0, world: 0, tech: 0, business: 0, culture: 0 };
  for (const a of state.articles) {
    if (counts[a.category] !== undefined) counts[a.category]++;
  }
  counts.top = state.articles.filter(a => a.category === "top").length || state.articles.length;
  return counts;
}

/* ============================================================
   Rendering
   ============================================================ */
function cardHTML(article, index) {
  const saved = state.bookmarks.has(article.link);
  const lang = hasBangla(article.title) ? ' lang="bn"' : "";
  const img = article.image
    ? `<div class="card-img-wrap"><img class="card-img" src="${escapeHTML(article.image)}"
         alt="" loading="lazy"
         onload="this.classList.add('loaded')"
         onerror="this.closest('.card-img-wrap').remove()"></div>`
    : "";
  return `
  <article class="card" style="animation-delay:${Math.min(index * 0.04, 0.4)}s">
    <div class="card-actions ${saved ? "pinned" : ""}">
      <button class="mini-btn share-btn" data-link="${escapeHTML(article.link)}"
              aria-label="Share article" title="Share">
        <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></svg>
      </button>
      <button class="mini-btn bookmark-btn ${saved ? "saved" : ""}"
              data-link="${escapeHTML(article.link)}"
              aria-label="${saved ? "Remove bookmark" : "Save article"}" title="${saved ? "Remove bookmark" : "Save article"}">
        <svg width="14" height="14" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
      </button>
    </div>
    ${img}
    <div class="card-body">
      <div class="card-meta">
        <span class="src">${escapeHTML(article.source || "Unknown")}</span>
        <span class="sep">·</span>
        <span>${escapeHTML(article.category || "")}</span>
      </div>
      <h2 class="card-title"${lang}>
        <a href="${escapeHTML(article.link)}" target="_blank" rel="noopener noreferrer">
          ${escapeHTML(article.title || "Untitled")}
        </a>
      </h2>
      ${article.summary ? `<p class="card-snippet">${escapeHTML(article.summary)}</p>` : ""}
      <div class="card-foot">
        <span class="card-time" data-ts="${escapeHTML(article.published || "")}">${timeAgo(article.published)}</span>
        <a class="read-link" href="${escapeHTML(article.link)}" target="_blank" rel="noopener noreferrer">Read →</a>
      </div>
    </div>
  </article>`;
}

function renderSkeletons() {
  grid.innerHTML = Array.from({ length: 8 }, () => `
    <div class="skeleton">
      <div class="sk-line w-40"></div>
      <div class="sk-line w-90"></div>
      <div class="sk-line w-75"></div>
      <div class="sk-line w-50"></div>
    </div>`).join("");
  emptyState.hidden = true;
}

function renderError() {
  grid.innerHTML = "";
  loadMoreWrap.hidden = true;
  errorBanner.hidden = false;
  errorText.textContent = "Couldn't reach data/news.json.";
  emptyState.hidden = false;
  emptyTitle.textContent = "News hasn't been generated yet";
  emptyMsg.textContent =
    "This is normal right after deploying. Fix: open your repo → Actions → “Fetch News” → Run workflow → wait ~30 seconds → refresh this page.";
}

function renderSources() {
  const sources = [...new Set(state.articles.map(a => a.source).filter(Boolean))].sort();
  const current = state.source;
  sourceFilter.innerHTML = `<option value="all">All sources (${sources.length})</option>` +
    sources.map(s => `<option value="${escapeHTML(s)}">${escapeHTML(s)}</option>`).join("");
  sourceFilter.value = sources.includes(current) ? current : "all";
  state.source = sourceFilter.value;
}

function render() {
  const cat = CATEGORIES[state.category] || CATEGORIES.top;
  feedTitle.textContent = cat.label;
  feedSub.textContent = cat.sub;

  updatedBadge.classList.toggle("offline", state.offline);
  updatedText.textContent = (state.offline ? "offline · " : "Updated ") + formatUpdated(state.lastUpdated);

  // Tab counts
  const counts = categoryCounts();
  document.querySelectorAll(".tab-count").forEach(el => {
    const c = el.dataset.cat;
    el.textContent = c === "bookmarks" ? state.bookmarks.size : (counts[c] ?? 0);
  });

  const list = visibleArticles();

  resultMeta.textContent = state.query
    ? `${list.length} result${list.length === 1 ? "" : "s"} for “${state.query}”`
    : `${list.length} article${list.length === 1 ? "" : "s"}`;

  grid.innerHTML = list.slice(0, state.shown).map(cardHTML).join("");

  const remaining = list.length - state.shown;
  loadMoreWrap.hidden = remaining <= 0;
  if (remaining > 0) loadMoreBtn.textContent = `Show more (${remaining} left)`;

  if (list.length === 0) {
    emptyState.hidden = false;
    if (state.category === "bookmarks" && !state.query && state.source === "all") {
      emptyTitle.textContent = "No saved articles";
      emptyMsg.textContent = "Hover any card and tap the bookmark icon to save it here.";
    } else {
      emptyTitle.textContent = "Nothing found";
      emptyMsg.textContent = "Try a different search, source filter, or check back soon.";
    }
  } else {
    emptyState.hidden = true;
  }

  renderBreaking();
}

function renderBreaking() {
  const breaking = state.articles.find(a => a.is_breaking) || state.articles[0];
  if (breaking && state.category !== "bookmarks" && !state.query) {
    breakingBar.hidden = false;
    breakingLink.href = breaking.link;
    breakingLink.textContent = breaking.title;
    breakingLink.lang = hasBangla(breaking.title) ? "bn" : "en";
  } else {
    breakingBar.hidden = true;
  }
}

/* Live-updating relative times (every 30s, no re-render) */
setInterval(() => {
  document.querySelectorAll(".card-time[data-ts]").forEach(el => {
    el.textContent = timeAgo(el.dataset.ts);
  });
}, 30000);

/* ============================================================
   Actions
   ============================================================ */
function findArticle(link) {
  return state.bookmarks.get(link) || state.articles.find(a => a.link === link);
}

function toggleBookmark(article) {
  if (state.bookmarks.has(article.link)) {
    state.bookmarks.delete(article.link);
    toast("Removed from saved");
  } else {
    state.bookmarks.set(article.link, article);
    toast("Saved");
  }
  saveBookmarks();
  render();
}

async function shareArticle(article) {
  const payload = { title: article.title, text: article.title, url: article.link };
  try {
    if (navigator.share) {
      await navigator.share(payload);
    } else {
      await navigator.clipboard.writeText(article.link);
      toast("Link copied to clipboard");
    }
  } catch { /* user cancelled share sheet — ignore */ }
}

grid.addEventListener("click", (e) => {
  const bBtn = e.target.closest(".bookmark-btn");
  if (bBtn) {
    e.preventDefault();
    const a = findArticle(bBtn.dataset.link);
    if (a) toggleBookmark(a);
    return;
  }
  const sBtn = e.target.closest(".share-btn");
  if (sBtn) {
    e.preventDefault();
    const a = findArticle(sBtn.dataset.link);
    if (a) shareArticle(a);
  }
});

/* Tabs */
tabs.addEventListener("click", (e) => {
  const btn = e.target.closest(".tab");
  if (!btn) return;
  activateTab(btn.dataset.cat);
});
function activateTab(cat) {
  state.category = cat;
  state.shown = PAGE_SIZE;
  tabs.querySelectorAll(".tab").forEach(t => {
    const on = t.dataset.cat === cat;
    t.classList.toggle("active", on);
    t.setAttribute("aria-selected", String(on));
  });
  render();
}

/* Search */
let searchDebounce;
searchInput.addEventListener("input", () => {
  clearTimeout(searchDebounce);
  searchDebounce = setTimeout(() => {
    state.query = searchInput.value;
    state.shown = PAGE_SIZE;
    render();
  }, 160);
});

/* Filters */
sourceFilter.addEventListener("change", () => {
  state.source = sourceFilter.value;
  state.shown = PAGE_SIZE;
  render();
});
sortSelect.addEventListener("change", () => {
  state.sort = sortSelect.value;
  render();
});

/* Load more */
loadMoreBtn.addEventListener("click", () => {
  state.shown += PAGE_SIZE;
  render();
});

/* Retry */
retryBtn.addEventListener("click", () => fetchNews());

/* Keyboard shortcuts */
document.addEventListener("keydown", (e) => {
  const typing = document.activeElement === searchInput;
  if (e.key === "/" && !typing) {
    e.preventDefault();
    searchInput.focus();
    return;
  }
  if (e.key === "Escape" && typing) {
    searchInput.value = "";
    state.query = "";
    state.shown = PAGE_SIZE;
    render();
    searchInput.blur();
    return;
  }
  if (!typing && (e.key === "ArrowRight" || e.key === "ArrowLeft")) {
    const order = ["top", "world", "tech", "business", "culture", "bookmarks"];
    let i = order.indexOf(state.category);
    i = e.key === "ArrowRight" ? (i + 1) % order.length : (i - 1 + order.length) % order.length;
    activateTab(order[i]);
  }
});

/* Theme */
const themeToggle = $("#themeToggle");
function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  try { localStorage.setItem("zyx_theme", theme); } catch {}
}
try {
  const saved = localStorage.getItem("zyx_theme");
  if (saved) applyTheme(saved);
  else if (window.matchMedia("(prefers-color-scheme: light)").matches) applyTheme("light");
} catch {}
themeToggle.addEventListener("click", () => {
  const cur = document.documentElement.getAttribute("data-theme");
  applyTheme(cur === "dark" ? "light" : "dark");
});

/* Back to top */
const toTop = $("#toTop");
window.addEventListener("scroll", () => {
  toTop.classList.toggle("visible", window.scrollY > 600);
}, { passive: true });
toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

/* Brand click → reset */
$("#brandHome").addEventListener("click", (e) => {
  e.preventDefault();
  searchInput.value = "";
  state.query = "";
  sourceFilter.value = "all";
  state.source = "all";
  activateTab("top");
  window.scrollTo({ top: 0, behavior: "smooth" });
});

/* ============================================================
   Boot: cache first (instant paint), then fresh fetch
   ============================================================ */
(function boot() {
  const cached = loadCache();
  if (cached) {
    state.articles = cached.articles || [];
    state.lastUpdated = cached.generated_at || null;
    render();
  }
  fetchNews({ silent: !!cached });

  // Register service worker (works on GitHub Pages, ignored locally)
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch(() => {});
    });
  }
})();

/* Auto-refresh: every 5 min + when user returns to the tab */
setInterval(() => fetchNews({ silent: true }), REFRESH_INTERVAL);
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) fetchNews({ silent: true });
});
