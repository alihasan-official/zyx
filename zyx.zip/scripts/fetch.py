#!/usr/bin/env python3
"""
zyx v3 — Bangladesh news aggregation engine.

- Tier 1 (bd_native=True):  Bangladeshi outlets & Bangla broadcasters — all stories kept.
- Tier 2 (bd_native=False): International outlets — only Bangladesh-related stories kept.
- Fetches 8 feeds concurrently, retries failed feeds, extracts article images.
- Re-classifies general BD news into tech/business/culture via EN+BN keywords
  so every tab has content.
- Dedupes, sorts newest-first, flags breaking stories, writes data/news.json.
"""

import gzip
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

try:
    import feedparser
except ImportError:
    raise SystemExit("feedparser is required: pip install feedparser")

# ---------------------------------------------------------------------------
# Feed registry: (url, category, source_name, bd_native)
# ---------------------------------------------------------------------------
FEEDS = [
    # ── Bangladeshi outlets — Bangla & English (all stories pass) ──────────
    ("https://www.prothomalo.com/feed/",                  "top",      "Prothom Alo",           True),
    ("https://www.thedailystar.net/rss/top.xml",          "top",      "The Daily Star",        True),
    ("https://www.dhakatribune.com/feed/",                "top",      "Dhaka Tribune",         True),
    ("https://bangla.bdnews24.com/feed/",                 "top",      "bdnews24 বাংলা",         True),
    ("https://www.banglatribune.com/feed/rss.xml",        "top",      "Bangla Tribune",        True),
    ("https://samakal.com/feed",                          "top",      "Samakal",               True),
    ("https://www.jugantor.com/feed",                     "top",      "Jugantor",              True),
    ("https://www.kalerkantho.com/rss.xml",               "top",      "Kaler Kantho",          True),
    ("https://www.ittefaq.com.bd/feed",                   "top",      "Ittefaq",               True),
    ("https://www.tbsnews.net/rss.xml",                   "business", "The Business Standard", True),
    ("https://thefinancialexpress.com.bd/feed/",          "business", "The Financial Express", True),

    # ── Bangla-language international broadcasters (all stories pass) ──────
    ("http://feeds.bbci.co.uk/bengali/rss.xml",           "top",      "BBC বাংলা",             True),
    ("https://rss.dw.com/rdf/rss-bn-all",                 "top",      "DW বাংলা",              True),
    ("https://www.voabangla.com/rss/",                    "top",      "VOA বাংলা",             True),
    ("https://www.rfa.org/bengali/rss2/rss2.xml",         "top",      "RFA বাংলা",             True),

    # ── International — FILTERED to Bangladesh-only stories ────────────────
    ("https://feeds.bbci.co.uk/news/world/asia/bangladesh/rss.xml",
                                                          "world",    "BBC News",              False),
    ("https://feeds.bbci.co.uk/news/world/asia/rss.xml",  "world",    "BBC Asia",              False),
    ("https://feeds.bbci.co.uk/news/technology/rss.xml",  "tech",     "BBC Tech",              False),
    ("https://www.aljazeera.com/xml/rss/all.xml",         "world",    "Al Jazeera",            False),
    ("https://www.theguardian.com/world/rss",             "world",    "The Guardian",          False),
]

# Bangladesh gate for international feeds
BANGLADESH_KEYWORDS = [
    "bangladesh", "bangladeshi", "bangla", "bengali", "bangali",
    "বাংলাদেশ", "বাঙালি", "বাংলা",
    "dhaka", "dacca", "chittagong", "chattogram", "sylhet", "khulna",
    "rajshahi", "barishal", "rangpur", "mymensingh", "cumilla", "comilla",
    "narayanganj", "gazipur", "bogura", "dinajpur", "noakhali",
    "cox's bazar", "coxs bazar", "sundarbans", "sundarban",
    "padma", "meghna", "jamuna", "buriganga",
    "bangabandhu", "sheikh hasina", "tarique rahman", "bnp", "awami league",
    "jamaat", "jatiya party", "bangladesh bank", "biman bangladesh",
    "grameen", "brac", "bkash", "bikash", "nogod", "bangladesh cricket", "bcb",
    "rmg", "readymade garment", "garment industry", "jute", "hilsha", "hilsa",
    "pohela boishakh", "bengali new year", "hartal", "blockade", "rohingya",
    "language movement", "suhrawardy", "bhasani", "ekushey",
]

# Re-classifier: route general "top" stories into richer tabs (EN + BN keywords)
RECLASS_RULES = [
    ("tech", [
        "technology", "tech", "ict", "startup", "artificial intelligence",
        "cyber", "internet", "software", "smartphone", "digital bangladesh",
        "satellite", "robot", "blockchain", "app",
        "প্রযুক্তি", "টেকনোলজি", "টেক", "আইসিটি", "স্টার্টআপ", "স্যাটেলাইট",
    ]),
    ("business", [
        "economy", "economic", "market", "stock", "taka", "export", "import",
        "trade", "bank", "inflation", "gdp", "budget", "remittance", "garment",
        "rmg", "jute", "share market", "dse", "bdt",
        "অর্থনীতি", "অর্থনীতি", "ব্যবসা", "বাজার", "শেয়ার", "রেমিট্যান্স",
        "বাজেট", "রপ্তানি", "মূল্যস্ফীতি", "ডলার",
    ]),
    ("culture", [
        "cricket", "football", "bangladesh tigers", "movie", "film", "cinema",
        "music", "festival", "literature", "culture", "pohela", "boishakh",
        "ekushey", "fashion", "food", "recipe", "travel", "tourism",
        "বিনোদন", "ক্রিকেট", "ফুটবল", "সিনেমা", "চলচ্চিত্র", "ঈদ", "উৎসব",
        "বই", "সাহিত্য", "সংগীত", "অভিনেতা", "অভিনেত্রী",
    ]),
    ("world", [
        "united nations", "world bank", "imf", "global", "international",
        "জাতিসংঘ", "আন্তর্জাতিক",
    ]),
]

BREAKING_KEYWORDS = [
    "breaking", "urgent", "developing", "live:", "alert",
    "dead", "dies", "killed", "attack", "explosion", "earthquake",
    "flood", "cyclone", "landslide", "fire", "accident",
    "resigns", "arrested", "emergency", "crisis", "hartal", "blockade",
]

REQUEST_TIMEOUT = 25
RETRIES = 2
MAX_WORKERS = 8
MIN_TOP_STORIES = 30
MAX_ARTICLES_PER_CATEGORY = 80
OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "news.json")
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 zyx/3.0"
)


# ---------------------------------------------------------------------------
# HTTP layer — the critical fix (feedparser gets bytes, not a URL + kwargs)
# ---------------------------------------------------------------------------
def http_get(url):
    """GET a URL with gzip, headers, and retries. Returns raw bytes."""
    last_err = None
    for attempt in range(RETRIES + 1):
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": USER_AGENT,
                "Accept": "application/rss+xml, application/atom+xml, "
                          "application/xml, text/xml, */*;q=0.8",
                "Accept-Encoding": "gzip",
                "Accept-Language": "en-US,en;q=0.9,bn;q=0.8",
                "Cache-Control": "no-cache",
            })
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
                raw = resp.read()
                if resp.headers.get("Content-Encoding", "").lower() == "gzip":
                    raw = gzip.decompress(raw)
                if len(raw) < 50:
                    raise ValueError("response too small — likely blocked")
                return raw
        except Exception as exc:
            last_err = exc
            time.sleep(1.2 * (attempt + 1))
    raise last_err


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------
def parse_timestamp(entry):
    for attr in ("published_parsed", "updated_parsed"):
        struct = entry.get(attr)
        if struct:
            try:
                return datetime.fromtimestamp(time.mktime(struct), tz=timezone.utc).isoformat()
            except (OverflowError, ValueError):
                pass
    for attr in ("published", "updated"):
        raw = entry.get(attr)
        if raw:
            try:
                dt = parsedate_to_datetime(raw)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                return dt.astimezone(timezone.utc).isoformat()
            except (TypeError, ValueError):
                pass
    return None


def clean_text(raw, limit=280):
    if not raw:
        return ""
    text = re.sub(r"<[^>]+>", " ", raw)
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"(?i)\s*(read more|continue reading|আরও পড়ুন).*$", "", text).strip()
    if len(text) > limit:
        text = text[:limit].rsplit(" ", 1)[0] + "…"
    return text


def normalize_title(title):
    t = (title or "").lower()
    t = re.sub(r"[^\w\s\u0980-\u09FF]", "", t)
    return re.sub(r"\s+", " ", t).strip()


def kw_match(text, keyword):
    """Word-boundary match for ASCII, substring for Bangla."""
    if re.search(r"[\u0980-\u09FF]", keyword):
        return keyword in text
    return re.search(r"\b" + re.escape(keyword) + r"\b", text) is not None


def is_bangladesh_related(title, summary):
    text = f"{title} {summary}".lower()
    return any(kw_match(text, kw) for kw in BANGLADESH_KEYWORDS)


def classify(text):
    t = text.lower()
    for cat, kws in RECLASS_RULES:
        for kw in kws:
            if kw_match(t, kw):
                return cat
    return None


def is_breaking(article):
    text = f"{article['title']} {article.get('summary', '')}".lower()
    return any(kw_match(text, kw) for kw in BREAKING_KEYWORDS)


def extract_image(entry, base_link):
    candidates = []
    for m in entry.get("media_content", []):
        if m.get("url"):
            candidates.append(m["url"])
    for m in entry.get("media_thumbnail", []):
        if m.get("url"):
            candidates.append(m["url"])
    for enc in entry.get("enclosures", []):
        if (enc.get("type") or "").startswith("image"):
            candidates.append(enc.get("href") or enc.get("url"))
    for l in entry.get("links", []):
        if l.get("rel") == "enclosure" and "image" in (l.get("type") or ""):
            candidates.append(l.get("href"))
    html = entry.get("summary", "") or ""
    m = re.search(r'<img[^>]+src=["\']([^"\']+)', html)
    if m:
        candidates.append(m.group(1))

    bad_ext = (".mp3", ".mp4", ".wav", ".ogg", ".webp?")
    for url in candidates:
        if not url:
            continue
        u = urllib.parse.urljoin(base_link, url) if base_link else url
        if any(u.lower().split("?")[0].endswith(ext.rstrip("?")) for ext in bad_ext):
            continue
        if u.startswith("http"):
            return u
    return None


# ---------------------------------------------------------------------------
# Feed fetching
# ---------------------------------------------------------------------------
def fetch_feed(url, category, source, bd_native):
    mode = "native" if bd_native else "filtered"
    print(f"  ↳ {source} [{category}] ({mode})", flush=True)
    raw = http_get(url)
    feed = feedparser.parse(raw)

    if getattr(feed, "bozo", False) and not feed.entries:
        raise ValueError(f"parse error: {getattr(feed, 'bozo_exception', 'unknown')}")

    articles = []
    skipped = 0
    for entry in feed.entries[:40]:
        title = clean_text(entry.get("title", ""), limit=300)
        link = (entry.get("link") or "").split("#")[0].strip()
        if not title or not link:
            continue
        summary = clean_text(entry.get("summary") or entry.get("description") or "", limit=280)

        if not bd_native and not is_bangladesh_related(title, summary):
            skipped += 1
            continue

        articles.append({
            "title": title,
            "link": link,
            "summary": summary,
            "source": source,
            "category": category,
            "published": parse_timestamp(entry),
            "image": extract_image(entry, link),
        })
    if skipped:
        print(f"    · {skipped} non-Bangladesh stories filtered")
    return articles


def fetch_all():
    results, failures = [], []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = {
            pool.submit(fetch_feed, url, cat, src, native): (url, src)
            for url, cat, src, native in FEEDS
        }
        for fut in as_completed(futures):
            url, src = futures[fut]
            try:
                results.extend(fut.result())
            except Exception as exc:
                failures.append(f"{src}: {exc}")
                print(f"    ⚠ {src} failed — {exc}")
    return results, failures


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------
def main():
    print(f"zyx fetch started at {datetime.now(timezone.utc).isoformat()}")
    all_articles, failures = fetch_all()

    # Dedup by normalized title + URL
    seen_titles, seen_links, unique = set(), set(), []
    for art in all_articles:
        kt, kl = normalize_title(art["title"]), art["link"].rstrip("/").lower()
        if kt in seen_titles or kl in seen_links:
            continue
        seen_titles.add(kt)
        seen_links.add(kl)
        unique.append(art)

    # Sort newest first
    unique.sort(key=lambda a: a["published"] or "0000", reverse=True)

    # Re-classify surplus "top" stories into tech/business/culture/world
    top_seen = 0
    for art in unique:
        if art["category"] != "top":
            continue
        top_seen += 1
        if top_seen <= MIN_TOP_STORIES:
            continue
        new_cat = classify(f"{art['title']} {art.get('summary', '')}")
        if new_cat:
            art["category"] = new_cat

    # Flag breaking stories
    flagged = 0
    for art in unique:
        if flagged >= 3:
            break
        if is_breaking(art):
            art["is_breaking"] = True
            flagged += 1

    # Cap per category
    counts, final = {}, []
    for art in unique:
        c = art["category"]
        if counts.get(c, 0) >= MAX_ARTICLES_PER_CATEGORY:
            continue
        counts[c] = counts.get(c, 0) + 1
        final.append(art)

    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "scope": "bangladesh",
        "article_count": len(final),
        "sources": sorted({a["source"] for a in final}),
        "articles": final,
    }

    os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    print(f"✔ {len(final)} articles · {len(payload['sources'])} sources · "
          f"{len(failures)} failed feeds → {os.path.abspath(OUTPUT_PATH)}")

    if len(final) == 0:
        raise SystemExit("ERROR: 0 articles collected — check network/feed status")


if __name__ == "__main__":
    main()
